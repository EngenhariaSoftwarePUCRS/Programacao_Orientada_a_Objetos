module poo {
    requires javafx.controls;
    requires transitive javafx.graphics;
    exports poo;
}