public interface CardObserver{
    void cardSelected(CardView card);
}